import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, username, fullName, password } = body as {
      email?: string;
      username?: string;
      fullName?: string;
      password?: string;
    };

    if (!email || !username || !password) {
      return NextResponse.json(
        { error: 'Email, username and password are required.' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters long.' },
        { status: 400 }
      );
    }

    // Check if email or username already exists
    const existing = await db.user.findFirst({
      where: {
        OR: [{ email: email.toLowerCase() }, { username: username.toLowerCase() }],
      },
    });
    if (existing) {
      const field = existing.email === email.toLowerCase() ? 'Email' : 'Username';
      return NextResponse.json(
        { error: `${field} is already taken.` },
        { status: 409 }
      );
    }

    // NOTE: storing password as plaintext per explicit request. Re-enable hashing
    // (bcrypt) before allowing real users to sign up.
    const user = await db.user.create({
      data: {
        email: email.toLowerCase(),
        username: username.toLowerCase(),
        fullName: fullName?.trim() || null,
        password,
      },
      select: { id: true, email: true, username: true, fullName: true },
    });

    return NextResponse.json(
      { message: 'Account created successfully.', user },
      { status: 201 }
    );
  } catch (err) {
    console.error('[signup] error', err);
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
