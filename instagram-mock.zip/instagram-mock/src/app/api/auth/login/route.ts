import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { identifier, password } = body as {
      identifier?: string;
      password?: string;
    };

    if (!identifier || !password) {
      return NextResponse.json(
        { error: 'Please enter both your username/email and password.' },
        { status: 400 }
      );
    }

    // Allow login by either email or username
    const user = await db.user.findFirst({
      where: {
        OR: [
          { email: identifier.toLowerCase() },
          { username: identifier.toLowerCase() },
        ],
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'The username or email you entered does not belong to an account.' },
        { status: 401 }
      );
    }

    // NOTE: plaintext password comparison per explicit request. Re-enable
    // bcrypt.compare(password, user.passwordHash) before allowing real users.
    if (password !== user.password) {
      return NextResponse.json(
        { error: 'Sorry, your password was incorrect.' },
        { status: 401 }
      );
    }

    return NextResponse.json({
      message: 'Logged in successfully.',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        fullName: user.fullName,
      },
    });
  } catch (err) {
    console.error('[login] error', err);
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
