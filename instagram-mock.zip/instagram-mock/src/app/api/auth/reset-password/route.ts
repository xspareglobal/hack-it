import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Sets a new password for a user.
// SECURITY: this endpoint requires that an OTP has been verified within the
// last 10 minutes for the given identifier — we check that a recently-used
// PasswordReset record exists for the user. Without that check, anyone could
// reset any account.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { identifier, newPassword } = body as {
      identifier?: string;
      newPassword?: string;
    };

    if (!identifier || !newPassword) {
      return NextResponse.json(
        { error: 'Missing identifier or new password.' },
        { status: 400 }
      );
    }

    if (newPassword.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters long.' },
        { status: 400 }
      );
    }

    const user = await db.user.findFirst({
      where: {
        OR: [
          { email: identifier.toLowerCase() },
          { username: identifier.toLowerCase() },
        ],
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'No account found for that email or username.' },
        { status: 404 }
      );
    }

    // Verify that an OTP was consumed for this user within the last 10 minutes.
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);
    const recentVerified = await db.passwordReset.findFirst({
      where: {
        userId: user.id,
        used: true,
        createdAt: { gt: tenMinutesAgo },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!recentVerified) {
      return NextResponse.json(
        {
          error:
            'Your verification has expired. Please request a new code and verify it again.',
        },
        { status: 403 }
      );
    }

    // NOTE: storing password as plaintext per explicit request. Re-enable
    // bcrypt.hash(newPassword, 10) before allowing real users.
    await db.user.update({
      where: { id: user.id },
      data: { password: newPassword },
    });

    // Invalidate all remaining reset codes for this user.
    await db.passwordReset.updateMany({
      where: { userId: user.id },
      data: { used: true },
    });

    return NextResponse.json({
      message: 'Your password has been reset. You can now log in.',
    });
  } catch (err) {
    console.error('[reset-password] error', err);
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
