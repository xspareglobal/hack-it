import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Verifies the 6-digit OTP. If valid, marks it as consumed so it can't be replayed.
// The client then sends the new password together with the identifier to /reset-password,
// which checks that a recently-verified OTP exists for that user.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { identifier, otp } = body as { identifier?: string; otp?: string };

    if (!identifier || !otp) {
      return NextResponse.json(
        { error: 'Please enter both your email/username and the code.' },
        { status: 400 }
      );
    }

    const user = await db.user.findFirst({
      where: {
        OR: [
          { email: identifier.toLowerCase() },
          { username: identifier.toLowerCase() },
        ],
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'No account found for that email or username.' },
        { status: 404 }
      );
    }

    const reset = await db.passwordReset.findFirst({
      where: {
        userId: user.id,
        used: false,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!reset || reset.otp !== otp.trim()) {
      return NextResponse.json(
        { error: 'That code is invalid or has expired. Please request a new one.' },
        { status: 400 }
      );
    }

    // Mark this OTP as used so it can't be replayed.
    await db.passwordReset.update({
      where: { id: reset.id },
      data: { used: true },
    });

    return NextResponse.json({
      message: 'Code verified. You can now set a new password.',
      verified: true,
    });
  } catch (err) {
    console.error('[verify-otp] error', err);
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
