import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';
import { sendOtpEmail, isSmtpConfigured } from '@/lib/mailer';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { identifier } = body as { identifier?: string };

    if (!identifier) {
      return NextResponse.json(
        { error: 'Please enter your email or username.' },
        { status: 400 }
      );
    }

    const user = await db.user.findFirst({
      where: {
        OR: [
          { email: identifier.toLowerCase() },
          { username: identifier.toLowerCase() },
        ],
      },
    });

    // Always respond 200 to avoid leaking which accounts exist.
    if (!user) {
      return NextResponse.json({
        message:
          'If that account exists, a verification code has been sent to the linked email.',
        sent: false,
      });
    }

    // Invalidate any previous unused OTPs for this user
    await db.passwordReset.updateMany({
      where: { userId: user.id, used: false },
      data: { used: true },
    });

    // Generate a 6-digit code, valid for 10 minutes
    const otp = crypto.randomInt(100000, 999999).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await db.passwordReset.create({
      data: { userId: user.id, otp, expiresAt },
    });

    // Try sending via SMTP. Fall back to dev-only behavior if SMTP isn't configured
    // so the demo flow remains testable without an email provider.
    const smtpReady = isSmtpConfigured();
    let emailed = false;

    if (smtpReady) {
      const result = await sendOtpEmail({ to: user.email, otp });
      emailed = result.ok;
      if (!emailed) {
        // SMTP was configured but delivery failed — surface the error so it
        // doesn't fail silently, but still return a generic message.
        console.error('[forgot-password] SMTP send failed:', result.error);
      }
    }

    return NextResponse.json({
      message:
        smtpReady && emailed
          ? 'A 6-digit verification code has been sent to the email linked to your account.'
          : 'A verification code was generated. Check your inbox (and spam folder).',
      sent: true,
      // Demo-only fallback so the flow is testable when SMTP isn't configured
      // or delivery failed. Removed in production.
      debugOtp: smtpReady && emailed ? undefined : otp,
      email: user.email,
      delivery: smtpReady && emailed ? 'email' : 'dev-toast',
    });
  } catch (err) {
    console.error('[forgot-password] error', err);
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    );
  }
}
